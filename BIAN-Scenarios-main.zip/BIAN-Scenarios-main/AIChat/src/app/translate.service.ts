import { Injectable } from '@angular/core'
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http'
import { Observable, catchError, retry, throwError } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class TranslateService {
  private url = 'http://localhost:4400/translate'

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }
  constructor (private httpClient: HttpClient) {}

  async translateText(data: string): Promise<string> {
    var myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
  
    var raw = JSON.stringify({
      text: data
    });

    try {
      const response = await fetch('http://localhost:4400/translate', {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow' // Provide a valid value for the redirect property
      });
      const result = await response.text();
      console.log("Translatedt Text in Translate Service: " + result);
      return result;
    } catch (error) {
      console.log('error', error);
      return (error as Error).toString();
    }
  }
}
