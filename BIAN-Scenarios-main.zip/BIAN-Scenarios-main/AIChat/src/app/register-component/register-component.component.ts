import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ChatClientService } from '../chat-client.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-component',
  templateUrl: './register-component.component.html',
  styleUrls: ['./register-component.component.css']
})
export class RegisterComponentComponent {

  registerForm!: FormGroup;
  emailExistsError: string = '';
  constructor(private router: Router, private chatService: ChatClientService, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}$/)]],
    });
  }

  onRegister() {
    if (this.registerForm.valid) {
      const userDetails = {
        name: this.registerForm.value.firstName + ' ' + this.registerForm.value.lastName,
        email: this.registerForm.value.email,
        phone: this.registerForm.value.phone,
        password: this.registerForm.value.password
      };

      this.chatService.userRegistration(userDetails).subscribe(
        (res: any) => {
          console.log("Registration message:" + res);
          this.emailExistsError = '';
          alert("Regsitration Successful");
          this.router.navigate(['/login']);

         
        },
    
          (error: any) => {
            if (error && error === 'Email Exists') {
              this.emailExistsError = 'The User has been already registered with this email';
              console.log(this.emailExistsError);
            }
          });
         
        }
      
    }
  }

