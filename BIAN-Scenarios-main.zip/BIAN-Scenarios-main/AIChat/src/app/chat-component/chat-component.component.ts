import {
  Component,
  OnInit,
  HostListener,
  ChangeDetectorRef,
  AfterContentChecked,
  OnDestroy
} from '@angular/core'
import { ChatClientService } from '../chat-client.service'
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { VoiceInputService } from 'src/app/voice-input.service'
import { Router } from '@angular/router'
import { TranslateService } from 'src/app/translate.service'

@Component({
  selector: 'app-chat-component',
  templateUrl: './chat-component.component.html',
  styleUrls: ['./chat-component.component.css']
})
export class ChatComponentComponent
  implements OnInit, OnDestroy, AfterContentChecked
{
  title: string = ''
  showSpinner: boolean = false

  // Keep active api calls subscription.
  public searchForm: FormGroup
  public isUserSpeaking: boolean = false
  selectedLanguage: string = 'en-US'
  translatedText: string = ''
  //Add a constructor

  constructor (
    private fb: FormBuilder,
    private voiceRecognition: VoiceInputService,
    private router: Router,
    private restService: ChatClientService,
    private changeDetector: ChangeDetectorRef,
    private translateService: TranslateService
  ) {
    // Initialize form group.
    this.searchForm = this.fb.group({
      searchText: ['', Validators.required]
    })
  }
  //add messages as a JSON array
  samplePrompts: any[] = [
    'What are the sequence of steps for Buy Now Pay Later Scenarios?',
    'What are the steps in underwriting?',
    'What are the service domains involved in the Processing of Closing of Uncollateralised Consumer Loan?',
    'Which scenario handles collateral administration?'
  ]

  // Will be fetced from API later. Hard coded for now
  recentQueries: any[] = [
    {
      query: 'What are the sequence of steps for Buy Now Pay Later Scenarios?',
      response:
        '- Card Capture: A distributed facility to capture card transactions at the point of sale\n- CR - CreditChargeCardFinancialCaptureTransaction: Handles instantiating a new Transaction Capture',
      timeStamp: 1701341752847
    }
  ]

  messages: any[] = [
    {
      message: 'Hello, how can I help you?',
      timestamp: new Date(),
      sender: 'AI',
      color: 'darkgreen'
    }
  ]
  //add a humanMessage object
  humanMessage: any = {
    message: '',
    timestamp: new Date(),
    sender: 'Human',
    color: 'red'
  }
  //add a botMessage object
  botMessage: any = {
    message: '',
    timestamp: new Date(),
    sender: 'AI',
    color: 'darkgreen'
  }
  aiMessage: any[] = []

  ngOnDestroy (): void {
    throw new Error('Method not implemented.')
  }

  ngAfterContentChecked (): void {
    this.changeDetector.detectChanges()
  }
  ngOnInit () {
    // Initialization code goes here
    this.title = 'AIChat'
    this.initVoiceInput()
  }
  stopRecording () {
    this.voiceRecognition.stop()
    this.isUserSpeaking = false
  }
  initVoiceInput () {
    // Subscription for initializing and this will call when user stopped speaking.
    this.voiceRecognition.init().subscribe(() => {
      // User has stopped recording
      // Do whatever when mic finished listening
    })

    // Subscription to detect user input from voice to text.
    this.voiceRecognition.speechInput().subscribe(input => {
      // Set voice text output to
      // Set voice text output to
      console.log('received Input: ' + input)
      this.searchForm.controls['searchText'].setValue(input)
      this.humanMessage.message = input
    })
  }
  setLanguage (value: string) {
    if (!value || value == '') {
      this.voiceRecognition.lang = 'en-US'
      this.selectedLanguage = 'en-US'
    } else {
      this.voiceRecognition.lang = value
      this.selectedLanguage = value
      alert('Selected Language is ' + value)
    }
  }
  /**
   * @description Function to enable voice input.
   */
  startRecording () {
    this.isUserSpeaking = true
    //this.voiceRecognition.lang = language;
    this.voiceRecognition.start()
  }

  loadChatInput (event: any) {
    this.humanMessage.message = event.target.innerHTML
  }

  async sendMessage () {
    var m = this.humanMessage.message.trim()
    if (!m || m.length < 3) {
      alert('Please Enter A Question')
      return
    }
    var newMessage = {}

    this.showSpinner = true
    if (this.selectedLanguage == 'th-TH') {
      //alert("Sending text for translation: " + m)
      m = await this.translateService.translateText(m)
      //alert("m=" + m)
    }
    newMessage = {
      message: m,
      timestamp: new Date(),
      sender: 'Human',
      color: 'red'
    }

    this.messages.push(newMessage)
    this.humanMessage.message = ''

    this.getAIMessage(m)
  }

  clearText () {
    this.humanMessage.message = ''
    this.searchForm.controls['searchText'].reset()
  }
  //create a function that makes a POST request to the backend
  //and returns the response
  async getBotMessage (message: string) {
    const api = 'http://localhost:3000/vectorsearch'
    await fetch(api, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ query: message })
    }).then(response => {
      //return response.json();
      //console.log(response)
      console.log(`${response}`)
    })
  }
  async getAIMessage (message: string) {
    /*if(this.recentQueries.some(q=>q.query==message)){
      const newMessage = {
        message: this.recentQueries.find(q =>q.query==message).response,
        timestamp: new Date(),
        sender: 'AI',
        color: 'darkgreen'
      }
      this.messages.push(newMessage)
      this.showSpinner = false;
    }*/
    // else{
    this.restService
      .getVectorSearchResponse(message)
      .subscribe((response: any) => {
        //if response.answer begins with a newline character, remove it

        var m = `${response.answer}`
        m = m.replace(/^\s+|\s+$/g, '')
        console.log(JSON.stringify(m))
        const newMessage = {
          message: m,
          timestamp: new Date(),
          sender: 'AI',
          color: 'darkgreen'
        }

        this.messages.push(newMessage)
        this.recentQueries.push({
          query: message,
          response: m,
          timeStamp: Date.now()
        })
        this.showSpinner = false
        //reset the humanMessage object
        this.botMessage = {
          message: '',
          timestamp: new Date(),
          sender: 'Human',
          color: 'darkgreen'
        }
      })
    // }
  }

  logOut () {
    this.restService.userLogOut().subscribe(
      (res: any) => {
        this.router.navigate(['/login'])
      },
      (error: any) => {
        console.error('Error logging out:', error)
      }
    )
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyDown (event: KeyboardEvent) {
    if (event.key === 'Enter') {
      this.sendMessage()
    }
  }
}
