import { Injectable } from '@angular/core'
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse
} from '@angular/common/http'
import { Observable, throwError } from 'rxjs'
import { catchError, retry } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class ChatClientService {
  private restUrl = 'http://localhost:3000/vectorsearch'
  private url = 'http://localhost:4400'
  private isLoggedInFlag = false;
  private login_details: { email: string; password: any}  | undefined;

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  }
  constructor (private httpClient: HttpClient) {}
  getExpenseEntries (): Observable<any> {
    return this.httpClient
      .get(this.restUrl, this.httpOptions)
      .pipe(retry(3), catchError(this.httpErrorHandler))
  }

  getExpenseEntry (id: number): Observable<any> {
    return this.httpClient
      .get(this.restUrl + '/' + id, this.httpOptions)
      .pipe(retry(3), catchError(this.httpErrorHandler))
  }

  getVectorSearchResponse2(data: string): Observable<string> {
    return this.httpClient.post<string>(this.restUrl, data, this.httpOptions)
    .pipe(
       retry(3),
       catchError(this.httpErrorHandler)
    );
 }
 getVectorSearchResponse(data: string): Observable<string> {
  return this.httpClient.get<string>(this.restUrl + '?query=' + data,  this.httpOptions)
  .pipe(
     retry(3),
     catchError(this.httpErrorHandler)
  );
  }

  isLoggedIn(): boolean {
    return this.isLoggedInFlag;
  }

  userLogin(email: string, password: string): Observable<any> {
    this.login_details = { email, password };
    this.isLoggedInFlag = true;
    return this.httpClient.get(this.url + '/login', { params: this.login_details })
      .pipe(
        catchError(this.httpErrorHandler)
      );
  }

  userLogOut(): Observable<any> {
    const userName = this.login_details?.email;
    return this.httpClient.get(this.url + '/logout?email=' +userName, this.httpOptions)
      .pipe(
        catchError(this.httpErrorHandler)
      );
  }

 userRegistration(userDetails: any): Observable<any> {
  return this.httpClient.post(this.url + '/users/insert', userDetails, this.httpOptions)
    .pipe(
      catchError((error: HttpErrorResponse) => this.checkExistingEmail(error))
    );
}

  private checkExistingEmail(error: HttpErrorResponse): Observable<any> {
    this.isLoggedInFlag = false;
    if (error.error === 'Email Exists') {
     // console.log('Email already exists');
      return throwError('Email Exists'); 
    }
    else {
      return throwError('Some other error occurred'); 
    }
}


  private httpErrorHandler = (error: HttpErrorResponse) =>{
    this.isLoggedInFlag = false;
    if (error.error instanceof ErrorEvent) {
      console.error(
        'A client side error occurs. The error message is ' + error.message
      )
    } else {
      console.error(
        'An error happened in server. The HTTP status code is ' +
          error.status +
          ' and the error returned is ' +
          error.message
      )
    }

    return throwError('Error occurred. Please try again')
  }

}
