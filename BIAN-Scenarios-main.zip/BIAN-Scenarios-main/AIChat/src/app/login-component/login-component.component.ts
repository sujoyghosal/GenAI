import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ChatClientService } from '../chat-client.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent {
  username!: string;
  password!: string;
  loginError!: string;

  constructor(private router: Router, private chatService: ChatClientService) { }

  onLogin() {
    this.loginError = ''; // Reset login error on login attempt

    this.chatService.userLogin(this.username, this.password).subscribe(
      (res: any) => {
        console.log("Login response:", res);
        if (res) {
          alert("Login Successful");
          this.router.navigate(['/chat']);
        } else {
          this.loginError = 'Incorrect username or password';
        }
      },
      (error: any) => {
        console.error("Login error:", error);
        this.loginError = 'Incorrect username or password';
      }
    );
  }
}
