mongoimport --uri "mongodb://localhost:27017/GenAIDB?directConnection=true" --collection BIANScenarios --type json --file scenarios.json
