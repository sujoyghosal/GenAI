mongoexport --uri mongodb+srv://sujoyghosal:Joyita_1@cluster0.dbxxvmy.mongodb.net/BIANDemo --collection BIANBusinessScenarios --type json --out scenarios.json
