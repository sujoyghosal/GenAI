// Loads the configuration from config.env to process.env
const express = require('express')
const mongodb = require('mongodb')
var http = require('http')
const cors = require('cors')
const bodyParser = require('body-parser')
const socketIO = require('socket.io')
const PORT = process.env.PORT || 4400
const app = express()
var loggedinUsers = []
app.use(cors())
app.use(express.json())
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())



app.use(function (err, _req, res, next) {
  console.error(err.stack)
  res.status(500).send('Something broke!')
})
const openai_key = process.env.OPENAI_API_KEY || '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'
let dbConnection

const { MongoClient, ServerApiVersion } = require('mongodb')
const uri = 'mongodb://localhost:27017/?directConnection=true'
console.log('MongoDB URL=' + uri)
const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: false,
  serverApi: ServerApiVersion.v1
})
client.connect(err => {
  dbConnection = client.db('GenAIDB')
  //dbConnection = client.db("rhelopenshifttest");
  // perform actions on the collection object
  console.log('Successfully connected to MongoDB - BIAN DB..' + uri)
  //client.close();
})

const httpServer = http.createServer(app).listen(PORT, function (req, res) {
  console.log('listening on *:' + PORT)
})
const io = socketIO(httpServer)

io.on('connection', socket => {
  console.log('A new user connected')

  // Attach the io instance to the req object
  socket.on('authentication', data => {
    socket.request.io = io
    // Rest of the authentication process...
  })

  // Rest of the code...
})

app.get('/', (req, res) => {
  res.send('Hi, Welcome to the PCF to OpenShift APIs')
})
app.get('/users', (req, res) => {
  console.log('Fetching user for email ' + req.query.email)
  dbConnection
    .collection('Users')
    .find({
      email: {
        $eq: req.query.email
      }
    })
    .limit(50)
    .toArray(function (err, result) {
      if (err) {
        res.status(400).send('Error fetching users!' + err)
      } else {
        res.json(result)
      }
    })
})
app.get('/login', (req, res) => {
  const ioInstance = req.io
  dbConnection
    .collection('Users')
    .find({
      email: {
        $eq: req.query.email
      }
    })
    .limit(1)
    .toArray(function (err, result) {
      if (err) {
        res.status(400).send('Error fetching user - ' + err)
        console.log('Failed login for ' + req.query.email + ': ' + err)
      } else {
        //res.json(result);
        console.log('Login response: ' + JSON.stringify(result))
        console.log('req.query: ' + JSON.stringify(req.query))
        console.log('result: ' + JSON.stringify(result))
        if (
          result &&
          result.length > 0 &&
          checkPassword(req.query.password, result[0].pw)
        ) {
          res.status(200).jsonp(result[0])
          console.log('Success login for ' + req.query.email)
          var newUser = result[0]
          var found = false
          for (i = 0; i < loggedinUsers.length; i++) {
            if (loggedinUsers[i].email == newUser.email) {
              found = true
              break
            }
          }
          if (!found) {
            console.log(
              'New User has logged in, refreshing users list with ' +
                newUser.name
            )
            loggedinUsers.push(newUser)
          }
          //broadcast event to all loggedin users
          io.emit('new-loggedin-user', {
            newUser: result[0]
          })
        } else {
          res.status(400).send([])
          console.log('Failed login for ' + req.query.email)
        }
      }
    })
})

app.get('/logout', (req, res) => {
  const userIndex = loggedinUsers.findIndex(
    user => user.email === req.query.email
  )
  if (userIndex !== -1) {
    const loggedOutUser = loggedinUsers.splice(userIndex, 1)[0]
    io.emit('user-logged-out', { user: loggedOutUser })
    console.log('User ' + req.query.email + ' logged out')
    //console.log('logged in users: ' + JSON.stringify(loggedinUsers));
    res.status(200).json({ message: 'User logged out successfully' })
  } else {
    res.status(404).json({ message: 'User not found' })
  }
})

async function getUserByEmail (email) {
  if (!email || email == null || email.length < 3) {
    console.log('GetUserByEmail: Not a valid email')
    return
  }
  dbConnection
    .collection('User')
    .find({
      email: {
        $eq: email
      }
    })
    .limit(1)
    .toArray(function (err, result) {
      if (err) {
        console.log('Error fetching user!' + err)
        return null
      } else {
        //res.json(result);
        if (result && result.length > 0) {
          console.log('Email already exists ' + result[0])
          return true
        } else return false
      }
    })
}
var bcrypt = require('bcryptjs')
const { response } = require('express')
const { stringify } = require('querystring')
var encryptedPw = 'null'

function encryptPassword (password) {
  const saltRounds = 10
  const myPlaintextPassword = password
  var salt = bcrypt.genSaltSync(saltRounds)
  var hash = bcrypt.hashSync(myPlaintextPassword, salt)
  encryptedPw = hash
  console.log('Encrypted password=' + hash)
  return hash
}

function checkPassword (password, hash) {
  return bcrypt.compareSync(password, hash)
  //return true;
}

// This section will help you create a new record.
app.post('/users/insert', (req, res) => {
  var email = req.body.email
  if (!email || email == null || email.length < 3) {
    console.log('Not a valid email')
    return
  }
  console.log(JSON.stringify(req.body))
  dbConnection
    .collection('Users')
    .find({
      email: {
        $eq: email
      }
    })
    .limit(1)
    .toArray(function (err, result) {
      if (err) {
        console.log('Error fetching user!' + err)
        return null
      } else {
        //res.json(result);
        if (result && result.length > 0) {
          console.log('Email already exists ' + JSON.stringify(result[0]))
          res.status(400).send('Email Exists')
          return
        } else {
          encryptedPw = encryptPassword(req.body.password)
          const userDocument = {
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            //address: req.body.address,
            pw: encryptedPw,
            //ngo: req.body.ngo ? req.body.ngo : false,
            create_time: new Date()
          }

          dbConnection
            .collection('Users')
            .insertOne(userDocument, function (err, result) {
              if (err) {
                console.error(JSON.stringify(err))
                res.status(400).send('Error inserting user data!')
              } else {
                console.log(`Added a new user with id ${result.insertedId}`)
                res.status(201).json({ message: 'Success' })
              }
            })
        }
      }
    })
})

// This section will help you update a record by id.
app.put('/users/update'),
  (req, res) => {
    const userUpdateQuery = {
      _id: new mongodb.ObjectID(req.body.userID)
    }
    encryptedPw = encryptPassword(req.body.password)
    const updates = {
      $set: {
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone_number,
        address: req.body.address,
        pw: encryptedPw,
        ngo: req.body.ngo ? req.body.ngo : false,
        create_time: new Date()
      }
    }

    dbConnection
      .collection('Users')
      .updateOne(userUpdateQuery, updates, function (err, _result) {
        if (err) {
          console.error(JSON.stringify(err))
          res.status(400).send(`Error updating user id ${userUpdateQuery._id}!`)
        } else {
          console.log('1 document updated')
          res.status(200).send('Success')
        }
      })
  }

// This section will help you delete a record
app.delete('/users/delete', (req, res) => {
  console.log('Received delete request for cust id ' + req.body.userID)
  const custQuery = {
    userID: req.body.userID
  }

  dbConnection.collection('User').deleteOne(custQuery, function (err, _result) {
    if (err) {
      res.status(400).send(`Error deleting user with id ${custQuery.userID}!`)
    } else {
      console.log('1 document deleted')
      res.status(200).send()
    }
  })
})
app.post('/translate', async (req, res) => {
  console.log("Translate text request received!!");
  const { text } = req.body

  if (!text) {
    console.log("Translate: No text")
    return res.status(400).json({ error: 'Text to translate is required' })
  }

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/engines/davinci-codex/completions',
      {
        prompt: `Translate the following Thai text to English: "${text}"`,
        max_tokens: 60
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + openai_key // replace with your OpenAI key
        }
      }
    )

    const translatedText = response.data.choices[0].text.trim()
    console.log(translatedText);
    return res.json({ translatedText })
  } catch (error) {
    console.error(error)
    return res.status(500).json({ error: 'Error translating text' })
  }
})

//app.use(cors());
var whitelist = [
  'http://localhost:3000',
  'http://localhost:4200',
  'http://localhost:8080',
  'https://pcf-to-os-web-concession-kiosk.pcf-to-ocp-migration-c6c44da74def18a795b07cc32856e138-0000.us-south.containers.appdomain.cloud'
]
app.use(
  cors({
    origin: whitelist
  })
)
