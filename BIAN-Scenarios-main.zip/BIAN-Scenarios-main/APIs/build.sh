set -x
export DOCKER_DEFAULT_PLATFORM=linux/amd64
CT=sujoyacr.azurecr.io/bianscenariosearchapi
docker build -t $CT .
docker push $CT