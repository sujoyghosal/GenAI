#set kubectl context to the AKS cluster
az aks get-credentials --resource-group DigitalBankStarterPOC --name pcf-aks
az acr login -n sujoyacr
kubectl create secret docker-registry acr-credentials \
--docker-server=sujoyacr.azurecr.io \
--docker-username=sujoy.ghosal@eygdscoral.onmicrosoft.com \
--docker-password=Joyita@17