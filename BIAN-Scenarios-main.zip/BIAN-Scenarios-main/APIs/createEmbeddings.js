const fs = require('fs')
const axios = require('axios')
const request = require('request');
// Step 3: Connect to MongoDB
const openai_key = process.env.OPENAI_API_KEY
//console.log(openai_key)
//connect to MongoDB
const { MongoClient, ServerApiVersion } = require('mongodb')
const uri =
  'mongodb+srv://sujoyghosal:Joyita_1@cluster0.dbxxvmy.mongodb.net/?retryWrites=true&w=majority'
const jsonDataArray = []
// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true
  }
})


async function createEmbedding (jsonData) {
  const options = {
    method: 'POST',
    url: 'https://api.openai.com/v1/embeddings',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + openai_key
    },
    body: JSON.stringify({
      input: jsonData,
      model: 'text-embedding-ada-002'
    })
  };

  // Wrap the request in a promise
  return new Promise((resolve, reject) => {
    request(options, function(error, response) {
      if (error) {
        reject(error);
      } else {
        const body = JSON.parse(response.body);
        resolve(body.data[0].embedding);
      }
    });
  });
  
}
async function createEmbeddingFromFile () {
  try {
    // Connect to the MongoDB client
    await client.connect()

    // Step 4: Read the JSON document from a file

    // Read the filename from the command line arguments
    const filename = process.argv[2]
    if (!filename) {
      throw new Error('Please provide a filename as a command line argument.')
    }

    // Read the JSON document from the file
    const data = fs.readFileSync(filename, 'utf8')
    const jsonData = JSON.parse(data)
    //loop through jsonData.text["Business Scenarios"] array and create a JSON object for each element with fields "text" under which there is "Business Domain, "Context" and Business Scenario Object
    //console.log(jsonData.text["Business Scenarios"])
    for (i = 0; i < jsonData.text['Business Scenarios'].length; i++) {
      let businessScenario = jsonData.text['Business Scenarios'][i]
      //console.log(businessScenario)
      let businessScenarioObject = {
        text: {
          'Business Domain': jsonData.text['Business Domain'],
          Context: jsonData.text['Business Scenarios Context'],
          'Business Scenario': businessScenario['Scenario'],
          'Service Domains': businessScenario['Service Domains'],
          Sequence: businessScenario['Sequence']
        }
      }
      //console.log(JSON.stringify(businessScenarioObject));
      //create an embedding for each business scenario object
      console.log(
        'Creating embedding for ' +
          businessScenarioObject.text['Business Scenario']
      )
      businessScenarioObject.embedding = await createEmbedding(
        JSON.stringify(businessScenarioObject)
      )
      
      jsonDataArray.push(businessScenarioObject)
    }
    writeToDb(jsonDataArray).then(result => {
      console.log(result)
    })
  } catch (e) {
    console.error(e)
    return e
  }
}

// Create an embedding of the JSON and add it as a field called "embedding"

// Step 5: Write the JSON document to a MongoDB collection
async function writeToDb (jsonDataArray) {
  try {
    await client.connect()
    const db = client.db('BIANDemo') // Replace with your database name.
    const collection = db.collection('BIANBusinessScenarios') // Replace with your collection name.
    const result = await collection.insertMany(jsonDataArray)

    return `Inserted ${result.insertedCount} documents`
  } catch (e) {
    console.error(e)
    return e
  } finally {
    await client.close()
  }
}
createEmbeddingFromFile()
