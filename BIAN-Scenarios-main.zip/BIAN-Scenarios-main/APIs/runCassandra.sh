docker run -e DS_LICENSE=accept --name my-dse -p 9042:9042 -d cr.dtsx.io/datastax/dse-server:6.8.37 -g -k -s
